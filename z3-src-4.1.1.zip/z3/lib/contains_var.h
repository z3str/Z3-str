/*++
Copyright (c) 2006 Microsoft Corporation

Module Name:

    contains_var.h

Abstract:

    <abstract>

Author:

    Leonardo de Moura (leonardo) 2007-06-12.

Revision History:

--*/
#ifndef _CONTAINS_VAR_H_
#define _CONTAINS_VAR_H_

class ast;

bool contains_var(ast * n);

#endif /* _CONTAINS_VAR_H_ */

