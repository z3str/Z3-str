export PATH=../../bin:$PATH
./example.exe
