g++ -fopenmp -o example.exe -I ../../include ../../bin/z3.dll example.cpp
